# Myanmar Karaoke Pro (Android)

Kotlin + Jetpack Compose + Material 3 + AndroidX Media3 ExoPlayer.

## Included in this starter build
- Professional dark karaoke-style interface
- Select local audio files through Android file picker
- Play a direct HTTPS audio stream URL
- Playback controls and seek bar
- Mic monitor permission flow and basic PCM mic loopback with gain/echo mix
- Mic mixer screen, music volume, echo control UI
- GitHub Actions workflow to build a debug APK

## Build
Requires JDK 17 and Gradle 8.9:
```bash
gradle assembleDebug
```
APK output: `app/build/outputs/apk/debug/app-debug.apk`

Or push to GitHub and run the `Build Myanmar Karaoke APK` workflow under Actions.

## Important limitations
- Online mode accepts direct HTTPS audio stream URLs. It is not a catalog/search service; connect a licensed music provider/API to add searchable online songs.
- Mic monitoring is device-dependent and may have latency. Use wired/Bluetooth headphones (wired is preferred) to reduce feedback. Some devices restrict simultaneous mic and media playback.
- Echo is a simple software delay effect. Reverb, pitch/key, tempo, timed lyrics, queue persistence, and provider integration are not implemented in this starter.
- Test on the target Android device before public distribution.
