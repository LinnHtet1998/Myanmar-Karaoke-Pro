package com.myanmar.karaokepro

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.media.audiofx.AutomaticGainControl
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.delay

private val Bg = Color(0xFF090D18)
private val Panel = Color(0xFF151D2E)
private val Accent = Color(0xFF8B5CF6)
private val Cyan = Color(0xFF22D3EE)

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    private var micEngine: MicMonitor? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Accent, secondary = Cyan,
                    background = Bg, surface = Panel
                )
            ) {
                KaraokeScreen(
                    player = player!!,
                    onMicPermission = { granted ->
                        if (granted) {
                            if (micEngine == null) micEngine = MicMonitor()
                            micEngine?.start()
                        }
                    },
                    onMicStop = { micEngine?.stop() },
                    onMicSettings = { gain, echo -> micEngine?.let { it.gain = gain; it.echo = echo } }
                )
            }
        }
    }

    override fun onDestroy() {
        micEngine?.stop()
        player?.release()
        super.onDestroy()
    }
}

@Composable
private fun KaraokeScreen(
    player: ExoPlayer,
    onMicPermission: (Boolean) -> Unit,
    onMicStop: () -> Unit,
    onMicSettings: (Float, Float) -> Unit
) {
    var currentSong by remember { mutableStateOf("သီချင်းရွေးချယ်ပါ") }
    var playing by remember { mutableStateOf(false) }
    var micOn by remember { mutableStateOf(false) }
    var micVolume by remember { mutableFloatStateOf(0.65f) }
    var musicVolume by remember { mutableFloatStateOf(0.75f) }
    var echo by remember { mutableFloatStateOf(0.20f) }
    var onlineUrl by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(0) }
    var duration by remember { mutableLongStateOf(0L) }
    var position by remember { mutableLongStateOf(0L) }
    val context = androidx.compose.ui.platform.LocalContext.current

    val audioPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    it, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            player.setMediaItem(MediaItem.fromUri(it))
            player.prepare()
            player.play()
            currentSong = it.lastPathSegment ?: "Local Audio"
            playing = true
        }
    }

    val micPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        micOn = granted
        onMicPermission(granted)
    }

    LaunchedEffect(player) {
        while (true) {
            duration = player.duration.coerceAtLeast(0L)
            position = player.currentPosition.coerceAtLeast(0L)
            playing = player.isPlaying
            delay(500)
        }
    }
    LaunchedEffect(musicVolume) { player.volume = musicVolume }
    LaunchedEffect(micVolume, echo) { onMicSettings(micVolume, echo) }

    Column(
        Modifier.fillMaxSize().background(Bg).padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(14.dp), color = Accent) {
                Icon(Icons.Default.MusicNote, null, tint = Color.White,
                    modifier = Modifier.padding(10.dp).size(26.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("MYANMAR KARAOKE", color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
                Text("PRO AUDIO MIXER", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp)
            }
            Icon(Icons.Default.GraphicEq, null, tint = Cyan, modifier = Modifier.size(28.dp))
        }

        Spacer(Modifier.height(18.dp))
        Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier.size(112.dp).background(
                        Color(0xFF242044), RoundedCornerShape(28.dp)
                    ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Mic, null, tint = Cyan, modifier = Modifier.size(58.dp))
                }
                Spacer(Modifier.height(12.dp))
                Text(currentSong, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(if (playing) "NOW PLAYING" else "READY TO SING",
                    color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(12.dp))
                Slider(
                    value = if (duration > 0) position.toFloat().coerceIn(0f, duration.toFloat()) else 0f,
                    onValueChange = { if (duration > 0) player.seekTo(it.toLong()) },
                    valueRange = 0f..(duration.toFloat().coerceAtLeast(1f))
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(formatTime(position), color = Color.LightGray, fontSize = 11.sp)
                    Text(formatTime(duration), color = Color.LightGray, fontSize = 11.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { player.seekToPreviousMediaItem() }) {
                        Icon(Icons.Default.SkipPrevious, null, tint = Color.White)
                    }
                    FilledIconButton(
                        onClick = {
                            if (player.isPlaying) player.pause()
                            else if (player.mediaItemCount > 0) player.play()
                            playing = player.isPlaying
                        },
                        modifier = Modifier.size(58.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = Accent)
                    ) {
                        Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                            null, tint = Color.White, modifier = Modifier.size(32.dp))
                    }
                    IconButton(onClick = { player.seekToNextMediaItem() }) {
                        Icon(Icons.Default.SkipNext, null, tint = Color.White)
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))
        TabRow(selectedTabIndex = tab, containerColor = Bg, contentColor = Cyan) {
            listOf("သီချင်းများ", "Mic Mixer", "Settings").forEachIndexed { i, label ->
                Tab(selected = tab == i, onClick = { tab = i }, text = {
                    Text(label, fontSize = 12.sp)
                })
            }
        }

        when (tab) {
            0 -> {
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = { audioPicker.launch(arrayOf("audio/*")) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent)
                ) {
                    Icon(Icons.Default.FolderOpen, null)
                    Spacer(Modifier.width(8.dp))
                    Text("ဖုန်းထဲမှ သီချင်းရွေးရန်")
                }
                Spacer(Modifier.height(12.dp))
                Text("ONLINE AUDIO", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                OutlinedTextField(
                    value = onlineUrl, onValueChange = { onlineUrl = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("https://example.com/song.mp3") },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Link, null) }
                )
                Button(
                    onClick = {
                        if (onlineUrl.startsWith("https://")) {
                            player.setMediaItem(MediaItem.fromUri(onlineUrl.trim()))
                            player.prepare()
                            player.play()
                            currentSong = "Online Stream"
                            playing = true
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Icon(Icons.Default.PlayCircle, null); Spacer(Modifier.width(6.dp)); Text("Online သီချင်းဖွင့်မယ်") }
                Text("မှတ်ချက် - တရားဝင် MP3 / Audio Stream URL ကိုသာ ထည့်ပါ။",
                    color = Color.LightGray, fontSize = 11.sp)
            }
            1 -> {
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("MICROPHONE", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("နားကြပ်အသုံးပြုရန် အကြံပြုသည်", color = Color(0xFFFFC857), fontSize = 11.sp)
                    }
                    Switch(checked = micOn, onCheckedChange = { enabled ->
                        if (enabled) {
                            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
                                == PackageManager.PERMISSION_GRANTED) {
                                micOn = true
                                onMicPermission(true)
                            } else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                        } else {
                            micOn = false
                            onMicStop()
                        }
                    })
                }
                MixerSlider("Mic Volume", micVolume, { micVolume = it })
                MixerSlider("Music Volume", musicVolume, { musicVolume = it })
                MixerSlider("Echo Level", echo, { echo = it })
                Text("Mic monitor သည် ဖုန်း၏ အသံ hardware ပေါ်မူတည်၍ latency ကွာနိုင်သည်။",
                    color = Color.LightGray, fontSize = 11.sp)
            }
            else -> {
                Spacer(Modifier.height(14.dp))
                Text("APP SETTINGS", color = Cyan, fontWeight = FontWeight.Bold)
                SettingRow("Audio output", "ဖုန်း Speaker / Bluetooth")
                SettingRow("Language", "မြန်မာ")
                SettingRow("Version", "1.0.0")
                SettingRow("Theme", "Professional Dark")
                Text("Online playback အတွက် အင်တာနက်လိုအပ်သည်။",
                    color = Color.LightGray, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun MixerSlider(label: String, value: Float, onChange: (Float) -> Unit) {
    Column(Modifier.padding(vertical = 5.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Color.White, fontWeight = FontWeight.Medium)
            Text("${(value * 100).toInt()}%", color = Cyan)
        }
        Slider(value = value, onValueChange = onChange)
    }
}

@Composable
private fun SettingRow(title: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title, color = Color.White)
        Text(value, color = Color.LightGray)
    }
    HorizontalDivider(color = Color(0xFF293247))
}

private fun formatTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(total / 60, total % 60)
}

private class MicMonitor {
    @Volatile private var running = false
    @Volatile var gain: Float = 0.65f
    @Volatile var echo: Float = 0.20f
    private var recorder: AudioRecord? = null
    private var track: AudioTrack? = null
    private var worker: Thread? = null

    fun start() {
        if (running) return
        val rate = 44100
        val minIn = AudioRecord.getMinBufferSize(
            rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val minOut = AudioTrack.getMinBufferSize(
            rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minIn <= 0 || minOut <= 0) return
        try {
            recorder = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION, rate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                minIn * 2
            )
            track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                .setBufferSizeInBytes(minOut * 2)
                .setTransferMode(AudioTrack.MODE_STREAM).build()
            val aec = AcousticEchoCanceler.create(recorder!!.audioSessionId)
            aec?.enabled = true
            val ns = NoiseSuppressor.create(recorder!!.audioSessionId)
            ns?.enabled = true
            val agc = AutomaticGainControl.create(recorder!!.audioSessionId)
            agc?.enabled = false
            running = true
            recorder!!.startRecording()
            track!!.play()
            worker = Thread {
                val buffer = ShortArray(512)
                val delayBuffer = ShortArray(4096)
                var cursor = 0
                while (running) {
                    val count = recorder?.read(buffer, 0, buffer.size) ?: -1
                    if (count > 0) {
                        for (i in 0 until count) {
                            val delayed = delayBuffer[cursor].toInt()
                            val dry = buffer[i].toInt()
                            val mixed = (dry * gain + delayed * echo * 0.45f)
                                .toInt().coerceIn(-32768, 32767)
                            delayBuffer[cursor] = dry.toShort()
                            cursor = (cursor + 1) % delayBuffer.size
                            buffer[i] = mixed.toShort()
                        }
                        track?.write(buffer, 0, count)
                    }
                }
            }.apply { name = "KaraokeMicMonitor"; start() }
        } catch (_: Exception) {
            stop()
        }
    }

    fun stop() {
        running = false
        try { worker?.join(250) } catch (_: InterruptedException) {}
        try { recorder?.stop() } catch (_: Exception) {}
        try { track?.stop() } catch (_: Exception) {}
        recorder?.release()
        track?.release()
        recorder = null
        track = null
        worker = null
    }
}
